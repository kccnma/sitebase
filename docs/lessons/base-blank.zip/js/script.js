document.addEventListener('DOMContentLoaded', function() {

    //JAVASCRIPT FUNCTIONS GO HERE

})
